# bachelorarbeit-mw
Dynamic Generation of Modular Industrial Plant Visualizations on a Manufacturing Execution System (MES) Interface
